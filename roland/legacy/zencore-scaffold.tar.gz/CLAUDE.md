# ZenCore — a Roland ZEN-Core `.svz` editor

Read this before touching anything. It records what is **verified** about the
file format versus what is **guessed**, and the rules that keep the difference
from blurring.

## Goal

A tool that can **load, save, create and modify** Roland ZEN-Core `.svz` files —
the format Zenology and ZEN-Core hardware (Fantom, Jupiter-X/Xm, MC-707/101,
Juno-X, Verselab) use to exchange tones.

Plan of record:

1. **Core library** (`zencore/`) — done, tested, byte-exact. Do not regress it.
2. **Local web UI** — next. Python serves a small HTTP API over the core; the
   browser renders the editor. Not started.
3. MIDI/SysEx to talk to hardware directly — **out of scope for now.** Do not
   add a MIDI dependency without asking.

## The one rule

> **Any `.svz` this project reads must be reproducible byte for byte.**

Every code path is built around that. `parse()` → `build()` is the identity
function on real files, and JSON export → import is too. This is not a nicety —
it is the only evidence we have that the format is understood, because we cannot
ask Roland and we cannot easily ask the hardware. When a round-trip breaks, the
model of the format is wrong. Fix the model, never loosen the test.

Corollary: **preserve what you don't understand.** Unknown chunks, padding
bytes, and the opaque `meta` field in variable chunks are all carried through
verbatim rather than normalised or zeroed.

## Verified facts

Confirmed by inspection of real files across three products
(`KY019$` v2.2 and v5.4, `RC001` v3.3) and five chunk kinds. Full detail in
[`docs/FORMAT.md`](docs/FORMAT.md).

- The container is **plain, uncompressed, unencrypted**. No obfuscation anywhere.
- Chunk header is `{u32 count; u32 recordSize; u32 headerSize; u32 flags}`
  with the invariant `headerSize == 16 + 4*count`, followed by
  `u32 crc32[count]` and then the records.
- The per-record checksum is a **plain `zlib.crc32`** of the record bytes.
- `recordSize == 0` marks the variable-length variant (the sample payload
  chunk), whose table is 16 bytes per entry.
- A tone record starts with a **16-byte ASCII name at offset 0**.
- `zcformat.json` `pos` values are **absolute** offsets into the tone record.
  The groups tile it contiguously and end at exactly 1632 for a PCM tone.

## Known unknowns

Do not write code that assumes an answer to any of these. If you resolve one,
move it up into "Verified facts" *with the evidence that settled it*.

- **Nothing has ever been loaded into hardware.** Every file this project
  writes is only known to satisfy our own parser. Until a synth accepts one,
  treat write support as unproven.
- The 4th field of a variable-chunk table entry (`meta`) is **not** a CRC-32 —
  that was tested and failed. Purpose unknown; carried through untouched.
- `MDLaZCOR` (2048-byte records, model-expansion data) has no schema entry, so
  it round-trips as opaque bytes. Its first 16 bytes look like a name.
- The `DIF` chunk's 32-byte record differs between products and is not decoded.
- Multi-byte parameters are **assumed** little-endian. Round-trip cannot detect
  a wrong endianness guess, so this is unproven for any field we have not seen
  vary.
- `ToneFile.create()` synthesises an init tone from the schema's `init` values.
  Plausible, unverified. Prefer copying an existing tone when it matters.

## Gotchas that already cost time

- Parameter ids are **only unique within a group** — `LEVEL` and `PAN` repeat
  across partials. A global `{id: param}` lookup silently writes to the wrong
  offset. Always resolve group-first.
- `LFO_n_STEP` is a **16-byte signed array**, not a scalar and not a name.
  Anything discriminating on `size == 16` will corrupt it. Discriminate on the
  parameter id for text, and on `size > 4` for arrays.
- The record size is **1632 for PCM tones and 2048 for MDL**, and other models
  may differ again. Read it from the chunk header; never hardcode it.
- The legacy script `legacy/read-svz.py` reads the tone name at offset **8**,
  which is wrong — it is offset 0. Do not copy offsets from `legacy/`; that
  directory is history, not reference.
- Real factory tones contain values outside the schema's documented `min`/`max`.
  `Tone.out_of_range()` is informational — never reject a file over it.

## Layout

```
zencore/            the library — this is the product
  container.py      chunk directory: parse/build, CRCs, nothing semantic
  schema.py         zcformat.json: absolute byte-map, encode/decode
  tone.py           Tone and ToneFile — the API a UI should call
  jsonio.py         lossless .svz <-> JSON
  cli.py            python3 -m zencore ...
tests/              pytest; tests/data/ holds the real-file corpus
docs/FORMAT.md      the binary format spec
tools/              schema extraction from Roland's editor XML
legacy/             superseded exploratory scripts, kept for history
JUPITERprmdb/       Roland's editor XML — the source zcformat.json came from
zcformat.json       generated parameter schema (do not hand-edit)
```

## Working commands

```bash
python3 -m pytest tests -q            # must stay green, always
python3 -m zencore info    FILE.svz
python3 -m zencore dump    FILE.svz -t 0
python3 -m zencore export  FILE.svz -o out/     # edit out/svz.json
python3 -m zencore build   out/ -o new.svz
python3 -m zencore create  -o new.svz -n 4
python3 -m zencore verify  *.svz
```

Library use:

```python
from zencore import Schema, ToneFile

tf = ToneFile.open("User.svz", Schema.load())
tf.tones[0].name = "My Patch"
tf.tones[0].set("PCMT_CMN", "LEVEL", 100)
tf.save("out.svz")
```

## How to work on this

- **Add to the corpus before adding a feature.** `tests/data/*.svz` is picked up
  automatically; every new file immediately gets round-trip, CRC and header
  coverage. A new model or chunk kind is worth more than new code.
- **Never widen an exception to make a file parse.** If `SvzError` fires, the
  file is telling you the format model is incomplete. Investigate, then either
  extend the model or record a new known-unknown here.
- **Keep `container.py` semantic-free.** It must not know what a tone is. That
  separation is what lets unknown chunk kinds survive an edit untouched.
- **Regenerating the schema:** `zcformat.json` is generated from
  `JUPITERprmdb/*.xml` by `tools/xml_to_schema.py`, which uses paths relative to
  the repo root — run it as `python3 tools/xml_to_schema.py` from there. Do not
  hand-edit `zcformat.json`; fix the extractor and regenerate, or the next
  regeneration silently drops the edit.
- Prefer stdlib. The core has no third-party dependencies and should keep none;
  the web UI may add exactly one small server dependency.

## Next step: the web UI

Not started. Intended shape when it is:

- A thin HTTP layer over `ToneFile` — the UI must not re-implement any format
  knowledge, and `zencore/` must not import anything web-related.
- Endpoints roughly: list tones in a loaded file, get one tone as grouped
  parameters (the `Schema.to_dict()` shape is already the right payload), patch
  a parameter, save.
- Render controls from the schema, not from hardcoded lists — `min`, `max`,
  `desc` and group names are all present, so the UI can be generated.
- Round-trip stays the acceptance test: load a file in the UI, save it without
  edits, and the bytes must be unchanged.
