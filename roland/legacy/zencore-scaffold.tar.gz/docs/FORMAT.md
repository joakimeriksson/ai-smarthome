# The Roland `.svz` container

Derived by inspection of real files. Every claim below is marked **verified**
(reproduced across multiple files) or **unverified** (consistent with what we
have seen, but not independently confirmed).

All integers are little-endian. Nothing in the file is compressed, encrypted,
or obfuscated — **verified** across every file examined.

## Corpus this is based on

| File | Product | Version | Chunks | Size |
|---|---|---|---|---|
| `EXPORT_Z-Core.svz` | `KY019$` | 2.2 | DIF, PAT×3 | 5 024 B |
| `EXPORT_Z-Core2.svz` | `KY019$` | 2.2 | DIF, PAT×1 | 1 752 B |
| `User.svz` | `RC001\x01` | 3.3 | DIF, PAT×1, MDL×2 | 5 888 B |
| `UpRightPiano1.svz` (Fantom-0) | `KY019$` | 5.4 | DIF, PAT×2, USP×44, MSP×4, USD×44 | 94.7 MB |

## File header

```
0x00  char magic[4]      "SVZa"                      verified
0x04  u8   version[2]    2.2 / 3.3 / 5.4 observed    verified
0x06  char product[6]    "KY019$", "RC001\x01"       verified
0x0C  u8   pad[4]        zero in every file          unverified (may not be pad)
0x10  DirEntry[]
```

The `product` field appears to identify the originating device or plugin. Its
exact meaning is **unverified** — treat it as an opaque tag and preserve it.

## Directory

```c
struct DirEntry {          // 16 bytes
    char id[8];            // e.g. "PATaZCOR"
    u32  offset;           // from start of file
    u32  length;
};
```

There is **no entry count**. The directory ends where the first chunk begins —
read entries until the next 8 bytes do not end in `ZCOR`, and cross-check
against `min(offset)`. **Verified.**

Chunks are contiguous and their lengths sum exactly to the file size in every
file examined. **Verified**, but do not rely on it — always use `offset`.

Observed chunk ids (`ZCOR` = ZEN-CORe):

| Id | Contents | Record size |
|---|---|---|
| `DIFaZCOR` | file/device info, not decoded | 32 |
| `PATaZCOR` | ZEN-Core tones | 1632 |
| `MDLaZCOR` | model expansion data | 2048 |
| `USPaZCOR` | user sample parameters | 64 |
| `MSPaZCOR` | multisample parameters | 1040 |
| `USDaZCOR` | raw sample payload | variable |

## Chunk, fixed-size records

Used by DIF, PAT, MDL, USP, MSP.

```c
u32 count;
u32 recordSize;        // non-zero
u32 headerSize;        // == 16 + 4*count          verified
u32 flags;             // 0 in every file observed  unverified
u32 crc32[count];      // zlib.crc32 of each record verified
u8  record[count][recordSize];
```

Two invariants worth asserting on read, because they catch a misparse
immediately:

```
headerSize == 16 + 4*count
headerSize + count*recordSize == chunkLength
```

The checksum is a **plain `zlib.crc32`** over the record's bytes — no seed, no
masking, no Roland-specific variation. **Verified** on every record in the
corpus. It must be recomputed whenever a record changes.

## Chunk, variable-size records

Used by `USDaZCOR`, the raw sample payload.

```c
u32 count;
u32 recordSize;        // == 0, this is the marker  verified
u32 headerSize;        // == 16 + 16*count          verified
u32 flags;
struct { u32 index; u32 offset; u32 length; u32 meta; } entry[count];
u8  payload[];
```

`offset` is measured **from the start of the chunk** and the entries are
contiguous — **verified** (entry *n+1*'s offset equals entry *n*'s offset plus
its length, across all 44 records).

`meta` is **not** a CRC-32; that hypothesis was tested against real sample data
and rejected. Purpose unknown. Carry it through unchanged.

## Tone record (`PAT`)

```
0x00  char name[16]      ASCII, space padded        verified
0x10  u8   params[...]   to recordSize
```

The name is at offset **0**, not 8. **Verified** across all four files:
`"UPiano1"`, `"OSC-SyncLd 4"`, `"wave seq 1"`, `"OscSync-Thriller"`.

`MDL` records also begin with a 16-byte name — **verified** but not otherwise
decoded.

### Parameter layout

Comes from `zcformat.json`, extracted from Roland's own editor XML
(`JUPITERprmdb/`). Each entry is `{id, desc, pos, size, min, max, init}`, and
`pos` is an **absolute** offset into the record — not relative to its group.
**Verified**: the groups tile the record contiguously from `PCMT_CMN` at 0 to
`PCMS_PTL_4` ending at exactly 1632.

Group order: `PCMT_CMN`, `MFX`, `PCMT_PMT`, `PCMT_PTL_1..4`, `PTL_PENV_1..4`,
`PTL_FENV_1..4`, `PTL_AENV_1..4`, `PTL_LFO_1..4`, `PTL_EQ_1..4`, `PCMS_CMN`,
`PCMS_PMT`, `PCMS_PTL_1..4`.

Encoding rules:

- `id == "NAME"` → 16-byte ASCII, space padded.
- `size > 4` → a byte array, not a scalar. `LFO_n_STEP` is 16 signed bytes.
- `min < 0` → two's complement. **Verified** for `PAN` (stored `0xF6` = −10 in
  `User.svz`); **unverified** as a general rule, though it holds everywhere we
  can check.
- Multi-byte scalars are read little-endian. **Unverified** — a wrong
  endianness guess survives a round-trip undetected, so this needs a value that
  actually varies to confirm.
- Entries without an `id` are padding. Preserve their bytes.

Parameter ids are unique only **within** a group. **Verified**, and a real
source of silent corruption if ignored.

## What this does not cover

- The meaning of `DIF` and `MDL` record contents.
- The `meta` field in variable chunks.
- `.SVD` files (`FANTOM.SVD` starts `^\x00SVD5`) — a different container.
- Whether hardware accepts a file we generated. **Nothing here has been
  round-tripped through a synth.**
